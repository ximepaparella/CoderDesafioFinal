//  SECCIÓN DE DECLARACIÓN DE INFORMACIÓN ESTÁTICA
const PROFESIONALES = [{
    "id": 1, 
    "nombre": "Juan",
    "apellido": "Molina",
    "dni": "33948484",
    "email":"jmolina@spabelgrano.com",
    "celular": 54114983839
  }, {
    "id": 2, 
    "nombre": "Maria",
    "apellido": "Galar",
    "dni": "24421731",
    "email":"mgalar@spabelgrano.com",
    "celular": 54119846372
  }, {
    "id": 3, 
    "nombre": "Analía",
    "apellido": "Fernandez",
    "dni": "15674983",
    "email":"afernandez@spabelgrano.com",
    "celular": 54114536487
  }];
